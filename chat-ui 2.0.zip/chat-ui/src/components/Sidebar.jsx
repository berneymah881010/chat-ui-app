import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faUser,
  faUsers,
  faCog,
  faComments,
  faEnvelope,
  faPhone,
  faMapMarkerAlt
} from "@fortawesome/free-solid-svg-icons";

function Sidebar({ selectedUser }) {
  return (
    <div
      className="sidebar"
      style={{
        width: "220px",
        padding: "20px",
        backgroundColor: "#2d2d2d",
        color: "#fff",
        borderRadius: "8px",
        height: "100%",
      }}
    >
      <h2 style={{ color: "#4fc3f7" }}>
        <FontAwesomeIcon icon={faComments} style={{ marginRight: "8px" }} />
        ChatApp
      </h2>

      <div style={{ marginTop: "30px" }}>
        <h4>User Profile</h4>
        {selectedUser ? (
          <div style={{ marginTop: "10px" }}>
            <img
              src={selectedUser.profileImage}
              alt="Profile"
              style={{ borderRadius: "50%", width: "60px", height: "60px" }}
            />
            <p style={{ margin: "10px 0 0", fontWeight: "bold" }}>{selectedUser.username}</p>
            <p style={{ fontSize: "12px", color: "#ccc" }}>{selectedUser.position}</p>

            {/* 添加用户详细信息 */}
            <p style={{ fontSize: "12px", color: "#aaa", marginTop: "8px" }}>
              <FontAwesomeIcon icon={faMapMarkerAlt} style={{ marginRight: "6px" }} />
              {selectedUser.address}
            </p>
            <p style={{ fontSize: "12px", color: "#aaa" }}>
              <FontAwesomeIcon icon={faPhone} style={{ marginRight: "6px" }} />
              {selectedUser.phone}
            </p>
            <p style={{ fontSize: "12px", color: "#aaa" }}>
              <FontAwesomeIcon icon={faEnvelope} style={{ marginRight: "6px" }} />
              {selectedUser.email}
            </p>
          </div>
        ) : (
          <p style={{ fontSize: "12px", color: "#aaa" }}>← Select a user</p>
        )}
      </div>

      <div style={{ marginTop: "40px" }}>
        <h4>Navigation</h4>
        <ul style={{ listStyle: "none", paddingLeft: "0", marginTop: "10px" }}>
          <li style={{ marginBottom: "10px", cursor: "pointer" }}>
            <FontAwesomeIcon icon={faUser} style={{ marginRight: "8px" }} />
            Users
          </li>
          <li style={{ marginBottom: "10px", cursor: "pointer" }}>
            <FontAwesomeIcon icon={faUsers} style={{ marginRight: "8px" }} />
            Groups
          </li>
          <li style={{ marginBottom: "10px", cursor: "pointer" }}>
            <FontAwesomeIcon icon={faCog} style={{ marginRight: "8px" }} />
            Settings
          </li>
        </ul>
      </div>
    </div>
  );
}

export default Sidebar;