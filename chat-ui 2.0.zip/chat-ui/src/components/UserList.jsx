import React, { useState } from "react";
// import { getUsers } from "../api"; // 

function UserList({ onSelectUser }) {
  const [search, setSearch] = useState("");

  const users = [
    {
      id: 1,
      username: "Jonathan",
      position: "Frontend Developer",
      address: "Malaysia",
      phone: "+60161111222",
      email: "jonathan@test.com",
      profileImage: "https://picsum.photos/id/91/500/500"
    },
    {
      id: 2,
      username: "Elizabeth Jan",
      position: "Backend Developer",
      address: "Malaysia",
      phone: "+60161111333",
      email: "elizabeth@test.com",
      profileImage: "https://picsum.photos/id/454/500/500"
    },
    // 
  ];

  const filtered = users.filter((user) =>
    user.username.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="user-list" style={{ padding: "10px" }}>
      <h3>🧑 User List</h3>
      <input
        type="text"
        placeholder="Search user..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{ width: "100%", marginBottom: "10px", padding: "5px" }}
      />
      {filtered.length === 0 ? (
        <p>No user found</p>
      ) : (
        filtered.map((user) => (
          <div
            key={user.id}
            onClick={() => {
  console.log("Selected user:", user);
  onSelectUser(user);
}}
            style={{
              padding: "8px",
              marginBottom: "5px",
              border: "1px solid #ccc",
              borderRadius: "5px",
              cursor: "pointer",
              backgroundColor: "#fff",
            }}
          >
            <b>{user.username}</b>
            <div style={{ fontSize: "0.8em", color: "#777" }}>
              {user.position}
            </div>
          </div>
        ))
      )}
    </div>
  );
}

export default UserList;