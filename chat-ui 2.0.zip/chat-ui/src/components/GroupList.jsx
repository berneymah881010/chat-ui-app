// src/components/GroupList.jsx
import React, { useState } from "react";

function GroupList({ onSelectGroup }) {
  const [search, setSearch] = useState("");

  const groups = [
    { id: 1, name: "Frontend Team" },
    { id: 2, name: "Backend Squad" },
    { id: 3, name: "Designers" },
  ];

  const filtered = groups.filter((group) =>
    group.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="group-list" style={{ padding: "10px", border: "1px solid #ccc", borderRadius: "8px" }}>
      <h3>👥 Group List</h3>
      <input
        type="text"
        placeholder="Search group..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{ width: "100%", marginBottom: "10px", padding: "5px" }}
      />
      {filtered.length === 0 ? (
        <p>No group found</p>
      ) : (
        filtered.map((group) => (
          <div
            key={group.id}
            onClick={() => onSelectGroup(group)}
            style={{
              padding: "8px",
              marginBottom: "5px",
              border: "1px solid #ccc",
              borderRadius: "5px",
              cursor: "pointer",
              backgroundColor: "#fff",
            }}
          >
            {group.name}
          </div>
        ))
      )}
    </div>
  );
}

export default GroupList;