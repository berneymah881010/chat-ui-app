import React, { useState } from "react";

function ChatWindow({ selectedUser, selectedGroup }) {
  const [searchText, setSearchText] = useState("");
  const [newMessage, setNewMessage] = useState("");

  if (!selectedUser && !selectedGroup) {
    return (
      <div style={{ flex: 1, padding: "10px", border: "1px solid #ddd" }}>
        <p>👈 Select a user or group to start chatting</p>
      </div>
    );
  }

  const mockMessages = selectedUser
    ? selectedUser.id === 1
      ? [
          { from: "me", text: "Hey Jonathan, are you free today?" },
          { from: "them", text: "Yeah, what's up?" },
          { from: "me", text: "Just checking in!" },
        ]
      : [
          { from: "me", text: "Hi Elizabeth, how's backend going?" },
          { from: "them", text: "Going strong! Almost done with API." },
          { from: "me", text: "Awesome! Keep it up." },
        ]
    : [
        { from: "Kevin", text: "Hey team, we need to finish this by Friday!" },
        { from: "Elizabeth", text: "I’m done with my part 💪" },
        { from: "Jonathan", text: "Working on UI right now." },
      ];

  const chatTitle = selectedUser
    ? `Chat with ${selectedUser.username}`
    : `Group: ${selectedGroup.name}`;

  const filteredMessages = mockMessages.filter((msg) =>
    msg.text.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <div
      className="chat-window"
      style={{
        flex: 1,
        padding: "10px",
        marginLeft: "10px",
        border: "1px solid #ccc",
        borderRadius: "8px",
        backgroundColor: "#f9f9f9",
      }}
    >
      <h3>💬 {chatTitle}</h3>

      <input
        type="text"
        placeholder="Search message..."
        value={searchText}
        onChange={(e) => setSearchText(e.target.value)}
        style={{
          width: "100%",
          marginBottom: "10px",
          padding: "8px",
          borderRadius: "5px",
          border: "1px solid #ccc",
        }}
      />

      <div
        style={{
          height: "300px",
          overflowY: "auto",
          marginBottom: "10px",
          background: "#fff",
          padding: "10px",
          border: "1px solid #eee",
        }}
      >
        {filteredMessages.length === 0 ? (
          <p style={{ textAlign: "center", color: "#888" }}>No message found</p>
        ) : (
          filteredMessages.map((msg, i) => (
            <div
              key={i}
              style={{
                textAlign: msg.from === "me" ? "right" : "left",
                margin: "5px 0",
              }}
            >
              <span
                style={{
                  display: "inline-block",
                  padding: "8px 12px",
                  background: msg.from === "me" ? "#cfe9ff" : "#eee",
                  borderRadius: "10px",
                }}
              >
                {msg.from !== "me" ? `${msg.from}: ` : ""}
                {msg.text}
              </span>
            </div>
          ))
        )}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          alert("Message sent (pretend)");
          setNewMessage("");
        }}
        style={{ display: "flex", gap: "10px" }}
      >
        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Type your message..."
          style={{ flex: 1, padding: "10px" }}
        />
        <button type="submit" style={{ padding: "10px 20px" }}>
          Send
        </button>
      </form>
    </div>
  );
}

export default ChatWindow;