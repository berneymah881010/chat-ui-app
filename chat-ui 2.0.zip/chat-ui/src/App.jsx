import React, { useState, useEffect } from "react";
import Sidebar from "./components/Sidebar";
import UserList from "./components/UserList";
import ChatWindow from "./components/ChatWindow";
import GroupList from "./components/GroupList";
import "./App.css";

function App() {
  // Load selected user from localStorage if available
  const [selectedUser, setSelectedUser] = useState(() => {
    const savedUser = localStorage.getItem("selectedUser");
    return savedUser ? JSON.parse(savedUser) : null;
  });

  const [selectedGroup, setSelectedGroup] = useState(null);

  const handleSelectUser = (user) => {
    setSelectedGroup(null); // Clear selected group if any
    setSelectedUser(user);
    localStorage.setItem("selectedUser", JSON.stringify(user)); // Persist to localStorage
  };

  const handleSelectGroup = (group) => {
    setSelectedUser(null); // Clear selected user if any
    setSelectedGroup(group);
    localStorage.removeItem("selectedUser"); // Remove saved user from localStorage
  };

  return (
    <div className="App" style={{ display: "flex", padding: "20px" }}>
      <Sidebar selectedUser={selectedUser} />
      <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
        <UserList onSelectUser={handleSelectUser} />
        <GroupList onSelectGroup={handleSelectGroup} />
      </div>
      <ChatWindow selectedUser={selectedUser} selectedGroup={selectedGroup} />
    </div>
  );
}

export default App;
