// src/api.js
import axios from "axios";

export const getUsers = () => axios.get(`/api/users/list`);
export const getGroups = () => axios.get(`/api/groups/list`);
export const getChats = () => axios.get(`/api/chat/list`);
export const getChatByUser = (id) => axios.get(`/api/chatByUserId/${id}`);
export const postChat = (fromUser, toUser, message) =>
  axios.post(`/api/chat/add`, { fromUser, toUser, message });
export const getUserDetail = (id) => axios.get(`/api/user/${id}`);